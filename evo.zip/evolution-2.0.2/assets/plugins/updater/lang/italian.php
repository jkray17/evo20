<?php
// ---------------------------------------------------------------
// :: Updater
// ----------------------------------------------------------------
//
//
//
// ----------------------------------------------------------------
// :: Copyright & Licencing
// ----------------------------------------------------------------
//
//   GNU General Public License (GPL - http://www.gnu.org/copyleft/gpl.html)
//

$_lang['pluginname'] = 'Updater';
$_lang['system_update'] = 'Aggiornamento di Sistema';
$_lang["cms_outdated_msg"] = 'Il Sistema di gestione dei contenuti è obsoleto. Per aggiornare contattare gli sviluppatori del sito. Versione attuale';
$_lang['bkp_before_msg'] = 'Si consiglia vivamente di fare un backup prima di aggiornare il sistema, l\'aggiornamento viene eseguito a proprio rischio !!';
$_lang['updateButton_txt'] = 'Aggiorna alla versione';
//Error Messages
$_lang['error_curl'] = 'È necessario abilitare la funzione CURL in PHP';
$_lang['error_zip'] = 'È necessario abilitare la funzione ZIP in PHP';
$_lang['error_openssl'] = 'È necessario abilitare la funzione OpenSSL in PHP';
$_lang['error_overwrite'] = 'I file di EVO non sono disponibili per la sovrascrittura';

