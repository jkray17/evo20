<?php
/**
 * Function:       English language file for custom settings
 * Encoding:       UTF-8
 * Author:         Deesen
 * Date:           2016/02/19
 * Version:        4.5.7.0
 * MODX version:   0.9.5-1.1
*/

$_lang['blockFormats_title'] = 'Block Formats';
$_lang['blockFormats_message'] = 'The enables you to specify a list of block formats for the block listbox. The format is &quot;title=block;&quot;.';