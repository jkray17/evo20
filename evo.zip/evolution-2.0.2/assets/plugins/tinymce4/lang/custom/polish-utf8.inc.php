<?php
/**
 * Function:       Polish language file for custom settings
 * Encoding:       UTF-8
 * Author:
 * Date:           2016/02/19
 * Version:        4.5.7.0
 * MODX version:   0.9.5-1.1
 */

$_lang['lang_code'] = 'pl';